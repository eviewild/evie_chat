local QBX = exports['qbx_core']

local function hasStaffPerm(src)
    local player = QBX:GetPlayer(src)
    if not player then return false end
    return player.PlayerData.permission == 'admin'
       or player.PlayerData.permission == 'god'
end

RegisterNetEvent('evie_chat:server:sendMessage', function(data)
    local src = source

    -- Broadcast chat UI message
    TriggerClientEvent('evie_chat:client:addMessage', -1, {
        name = GetPlayerName(src),
        type = data.type,
        message = data.message
    })

    -- Send 3D text for RP messages
    if data.type == 'me' or data.type == 'do' then
        TriggerClientEvent('evie_chat:client:display3DText', -1, src, {
            type = data.type,
            message = data.message
        })
    end
end)

RegisterNetEvent('evie_chat:server:send3DText', function(data)
    local src = source
    TriggerClientEvent('evie_chat:client:display3DText', -1, src, data)
end)

