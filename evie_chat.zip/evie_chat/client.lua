local chatOpen = false

-- Disable controls while chat is open
CreateThread(function()
    while true do
        if chatOpen then
            -- Disable ALL gameplay controls
            DisableAllControlActions(0)

            -- Re-enable ONLY what NUI needs
            EnableControlAction(0, 191, true) -- ENTER
            EnableControlAction(0, 322, true) -- ESC
            EnableControlAction(0, 245, true) -- Chat input (keyboard)
            EnableControlAction(0, 249, true) -- Push to talk (optional)

            -- Prevent pause menu soft-lock
            EnableControlAction(0, 200, true)
        end
        Wait(0)
    end
end)

RegisterCommand('chat', function()
    if chatOpen then return end

    chatOpen = true
    SetNuiFocus(true, true)

    SendNUIMessage({
        action = 'toggle',
        state = true
    })
end)

RegisterKeyMapping('chat', 'Open Chat', 'keyboard', 'T')

RegisterNetEvent('evie_chat:client:addMessage', function(data)
    SendNUIMessage({
        action = 'message',
        message = data
    })
end)

RegisterNUICallback('sendMessage', function(data, cb)
    local msg = data.message

    -- If message is a command
    if msg:sub(1,1) == '/' then
        ExecuteCommand(msg:sub(2))
        closeChat()
        cb(true)
        return
    end

    -- Normal chat message
    TriggerServerEvent('evie_chat:server:sendMessage', data)
    closeChat()
    cb(true)
end)

RegisterNUICallback('close', function(_, cb)
    closeChat()
    cb(true)
end)

function closeChat()
    chatOpen = false
    SetNuiFocus(false, false)

    SendNUIMessage({
        action = 'toggle',
        state = false
    })
end

local active3DTexts = {}

RegisterNetEvent('evie_chat:client:display3DText', function(src, data)
    local ped = GetPlayerPed(GetPlayerFromServerId(src))
    if not DoesEntityExist(ped) then return end

    table.insert(active3DTexts, {
        ped = ped,
        text = data.message,
        type = data.type,
        time = GetGameTimer() + 6000 -- 6 seconds
    })
end)

CreateThread(function()
    while true do
        local sleep = 1000
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)

        for i = #active3DTexts, 1, -1 do
            local data = active3DTexts[i]

            if GetGameTimer() > data.time or not DoesEntityExist(data.ped) then
                table.remove(active3DTexts, i)
            else
                local coords = GetEntityCoords(data.ped)
                local dist = #(playerCoords - coords)

                if dist < 20.0 then
                    sleep = 0
                    Draw3DText(coords.x, coords.y, coords.z + 1.0, data.text, data.type)
                end
            end
        end

        Wait(sleep)
    end
end)

function Draw3DText(x, y, z, text, type)
    local scale = 0.35

    if type == 'do' then
        scale = 0.32
    end

    SetTextScale(scale, scale)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextCentre(true)

    if type == 'me' then
        SetTextColour(255, 160, 160, 215)
    elseif type == 'do' then
        SetTextColour(160, 255, 180, 215)
    else
        SetTextColour(255, 255, 255, 215)
    end

    SetTextEntry("STRING")
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end
