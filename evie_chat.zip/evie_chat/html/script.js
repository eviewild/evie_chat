const root = document.getElementById('chat-root')
const messages = document.getElementById('messages')
const input = document.getElementById('text')
const commandsBox = document.getElementById('commands')
const mode = document.getElementById('mode')

const commands = [
    { cmd: '/me', type: 'me', desc: 'Action message' },
    { cmd: '/do', type: 'do', desc: 'Scene description' },
    { cmd: '/ooc', type: 'ooc', desc: 'Out of character' },
    { cmd: '/staff', type: 'staff', desc: 'Staff chat' }
]

window.addEventListener('message', (event) => {
    const data = event.data

    if (data.action === 'toggle') {
    root.style.display = data.state ? 'block' : 'none'
    commandsBox.style.display = 'none'
    if (data.state) {
        setTimeout(() => input.focus(), 10)
    }
}

    if (data.action === 'message') {
        const msg = document.createElement('div')
        msg.className = `message ${data.message.type}`
        msg.innerHTML = `<strong>${data.message.name}:</strong> ${data.message.message}`
        messages.appendChild(msg)
        messages.scrollTop = messages.scrollHeight
    }
})

/* Slash command suggestions */
input.addEventListener('input', () => {
    if (!input.value.startsWith('/')) {
        commandsBox.style.display = 'none'
        return
    }

    const value = input.value.toLowerCase()
    commandsBox.innerHTML = ''

    commands
        .filter(c => c.cmd.startsWith(value))
        .forEach(c => {
            const el = document.createElement('div')
            el.className = 'command'
            el.innerHTML = `<span>${c.cmd}</span> — ${c.desc}`

            el.onclick = () => {
    mode.innerText = c.type.toUpperCase()
    input.value = ''
    commandsBox.style.display = 'none'
    input.focus()
}

            commandsBox.appendChild(el)
        })

    commandsBox.style.display = commandsBox.children.length ? 'block' : 'none'
})

input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault()
        e.stopPropagation()

        if (input.value.trim() === '') return

        fetch(`https://${GetParentResourceName()}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: input.value.trim()
            })
        })

        input.value = ''
        commandsBox.style.display = 'none'
    }
})

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        fetch(`https://${GetParentResourceName()}/close`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        })
    }
})

document.addEventListener('keydown', (e) => {
    e.stopPropagation()
})
